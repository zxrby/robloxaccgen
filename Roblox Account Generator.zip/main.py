import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import os
import time
import secrets
import string
import random
from concurrent.futures import ThreadPoolExecutor

NOPECHA_KEY = 'YOUR_NOPECHA_KEY'  # Replace with your NopeCHA key.
nopecha_setup_url = "https://nopecha.com/setup#fdwblb2woo_Y4WPK25Y"
roblox_url = "https://www.roblox.com/"
chromedriver_path = "chromedriver.exe"  # Update with your actual path

options = webdriver.ChromeOptions()
options.add_argument('--no-sandbox')
options.add_argument('--disable-infobars')
options.add_argument('--disable-dev-shm-usage')
options.add_argument('--disable-blink-features=AutomationControlled')
options.add_experimental_option('excludeSwitches', ['enable-automation'])
options.add_experimental_option('useAutomationExtension', False)

# Download the latest NopeCHA crx extension file.
# You can also supply a path to a directory with unpacked extension files.
with open('ext.crx', 'wb') as f:
    f.write(requests.get('https://nopecha.com/f/ext.crx').content)
options.add_extension('ext.crx')

# Function to solve the CAPTCHA using NopeCHA
def solve_captcha(driver):
    try:
        captcha_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'captcha-class'))  # Adjust this locator based on your actual page
        )

        # Use NopeCHA API to solve the CAPTCHA
        driver.execute_script(
            f"window.nopecha.solve('{NOPECHA_KEY}', '{captcha_element.get_attribute('src')}');"
        )
    except Exception as e:
        print(f"Error solving CAPTCHA: {str(e)}")

def signup(_):
    username = generate_username()
    password = generate_password()

    driver = webdriver.Chrome(options=options)

    driver.get(nopecha_setup_url)
    time.sleep(2) 

    driver.get(roblox_url)
    time.sleep(2)
    try:
        accept_all_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CLASS_NAME, 'btn-cta-lg'))
        )
        accept_all_button.click()
        print("Clicked 'Accept All' button successfully.")
    except Exception as e:
        print(f"Error clicking 'Accept All' button: {str(e)}")
        return  #

    time.sleep(1)
    select_element = driver.find_element(By.ID, 'DayDropdown')
    select = Select(select_element)
    select.select_by_value('05')

    select_element = driver.find_element(By.ID, 'MonthDropdown')
    select = Select(select_element)
    select.select_by_value('Jan')

    select_element = driver.find_element(By.ID, 'YearDropdown')
    select = Select(select_element)
    select.select_by_value('2000')
    print("send year")

    time.sleep(2)
    driver.find_element(By.ID, 'signup-username').send_keys(username)
    print("send username")

    time.sleep(1)
    driver.find_element(By.ID, 'signup-password').send_keys(password)
    print("send password")

    solve_captcha(driver)

    time.sleep(2)
    try:
        signup_button = WebDriverWait(driver, 2).until(
            EC.element_to_be_clickable((By.NAME, 'signupSubmit'))
        )
        signup_button.click()
        time.sleep(5)
        if "home?nu=true" not in driver.current_url:
            print(f"Account creation failed for User: {username}, Password: {password}")
        else:
            print(f"User: {username}, Password: {password}")

    except Exception as e:
        print("Signup button didn't work. Error:", str(e))

    time.sleep(5)  
    driver.quit()

def generate_password(length=12):
    characters = string.ascii_letters + string.digits + string.punctuation
    return ''.join(secrets.choice(characters) for _ in range(length))

def generate_username(length=8):
    allowed_characters = string.ascii_letters + string.digits + '_'
    return ''.join(random.choice(allowed_characters) for _ in range(length))

num_threads = int(input("Enter the number of threads: "))
num_accounts = int(input("Enter the number of accounts to create: "))

with ThreadPoolExecutor(max_workers=num_threads) as executor:
    executor.map(signup, range(num_accounts))
